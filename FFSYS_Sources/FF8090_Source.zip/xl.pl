#!/usr/bin/perl -w
use Getopt::Long;
use Config;
use strict;

# General defaults
my $txt_path    = './main.asm';
my $root_fn = 'test';
my $label       = 'ZZL';
my $rc = 1;
my $wc = 0;
my $count = 0;
my $offset = 0;
my $semifl = 0;		# semicolon detect flag
my $new;
my $old = "\n";		# start file with newline as the phake previous chr

&GetOptions(
    "path=s"  => \$txt_path,
    "label=s" => \$label,
    "icnt=i"  => \$count,
);

print "icnt = $count\n";

# xl.pl : Crossbow relative label converion utility
# This script converts ":" relative labels from the Crossbow xasm application to absolute
#  labels.  This is an important step in porting Crossbow source files to a DOS/WIN xasm
#  application (like ASM11).  Other conversion activities (like adding "#" to include and
#  if/else directives, or changing "RES" to "DS" are left to other find/replace functions.
# Useage:
#  xl.pl --path <filename.xxx> ; --label <relative label text> > --offs <starting offset>
#
# <relative label text> is any valid ASM label (limit to 4 chrs if possible). The script
#  will apend a sequence number to the label text for each ":" character that is found
#  at the start of a line.  If no <relative label text> option is selected, "ZZL" is used.
#  Futhermore, any ":+n" or ":-n" (where n = 1 - 9) sequences will be replaced by the
#  <relative label text> with a sequence number that points to the nth previous or following
#  <relative label text> label.
#
# <starting offset> allows the sequencing to be carried over from a previous cycle.
#
# The output is directed to <filename.x2a>.  The extension is then changed post-process
#  by the user.
#
# The final value of offset is printed to the console for capture by the calling batch
#  to allow continuous sequencing across multiple files in a build package if desired.
#
# A batch file should be used to convert multiple files in a design.

$root_fn = $& if $txt_path =~ m/^\w+/;

open(IN, "<$txt_path") or die;
open(OUT, ">$root_fn.x2a") or die;
while ($rc != 0)
{
	# Read a byte - not safe for Unicode or other double-byte environments!
	$rc = read IN, $new, 1, 0;

	# First, see if the byte is a ":" preceded by a cr or lf (replace ":"
	#  with "RELx" where x is an integer that increases with each ":" match)
	if ((ord($old) == 13) || (ord($old) == 10))
	{
		$semifl = 0;		# clear semicolon flag
		if ($new =~ m/:/)
		{
			print OUT "$label$count";
			$count += 1;
			$old = 1;	# need something here besides 0, :, \n, or \r
		}
		else
		{
		if (ord($new) == 59)
		{
			$semifl = 1;
		}
		print OUT $new;
		$old = $new;
		}
	}
	else
	{
		# now, look for ":+" or ":-" instances and replace with "RELx" where
		# x is calculated from the digit following the + or -:
		#	for +, x = $count + digit - 1
		#	for -, x = $count - digit
		# This sequence should replace three characters (":-n" or ":+n") with
		# the new relative label "RELx" where x is calculated from the above.	

		if (ord($new) == 59)
		{
			$semifl = 1;
		}
		if (ord($old) == 58)		# ":" chr = ascii 58
		{
			if ((ord($new) == 43) && ($semifl == 0))
			{
				seek IN, 0, 1;
				$rc = read IN, $new, 1, 0;
				$offset = ord($new) - ord('1');
				$offset += $count;
				print OUT "$label$offset";
				$old = 1;
			}
			else
			{
				if ((ord($new) == 45) && ($semifl == 0))
				{
					# read offset value (a single digit, 1-9)
					seek IN, 0, 1;
					$rc = read IN, $new, 1, 0;
					$offset = ord($new) - ord('0');
					$offset = $count - $offset;
					print OUT "$label$offset";
					$old = 1;
				}
				else
				{
					# print the previous ":" and the new chr
					print OUT $old;
					print OUT $new;
					$old = $new;
				}
			}
		}
		else	# no translation, pass original chr to output
		{
			if(ord($new) == 58)	# if a ':', delay printing to see if it is part of a REL reference
			{
				$old = $new;
			}
			else
			{
				if($semifl == 1)	# after a semicolon, don't translate
				{
					print OUT $new;
					$old = $new;
				}
				else
				{
					if(ord($new) == 40)	#translate '(' to '{'
					{
						$new = '{';
					}
					if(ord($new) == 41)	#translate ')' to '}'
					{
						$new = '}';
					}
					if(ord($new) == 126)	#translate '~' to '$ff ^'
					{
						print OUT '$ff';
						$new = chr(94);
					}
					print OUT $new;
					$old = $new;
				}
			}
		}
	}
	# move on to the next byte
	seek IN, 0, 1;
}
close(IN);
close (OUT);
open(OUT2, ">x2a_icount.bat") or die;
print OUT2 "set S_ICNT=$count\n";
print OUT2 "\n";
close (OUT2);

