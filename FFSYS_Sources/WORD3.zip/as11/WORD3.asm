;_temp	ASSIGN	_temp+1
;	#IF	{{_temp} = TRUE & 1}
;	ALERT	"See OBJ.TXT for directions on forming EPROM files..."
;	#ENDIF

REVERSE	EQU	$ff	; ~0 for pre-bitreversed data
maxwords EQU 625		; rough guess for now...
SPKROM	EQU $0000		; U4 speech/code/data rom addresses
;SPKLEN	EQU $4000		; U4 rom length


;num	EQU	234
;mkr	EQU	244
;srvc	EQU	235
;ohh	EQU	$80
;one	EQU	$81
;two	EQU	$82
;tre	EQU	$83
;for	EQU	$84
;fiv	EQU	$85
;six	EQU	$86
;sev	EQU	$87
;eig	EQU	$88
;nin	EQU	$89
EOL	EQU	$D

;the WORD package contains speech data and xref tables for
;TMS53C30 LPC speech chip
;
;Fri, Oct 4, 2013, 21:00
;added fabricated word: OVERIDE
;changed spelling of decreasing to DECREASN to avoid conflict with DECREASE
;changed all "HEX" filename extensions to "asm"
;Mon, Jul 28, 2003, 14:37
;added provision for pre-bit reversed data (REVERSE)
;added abbreviated month/dow mirror words
;qc'd wordlist and updated spelling.  discovered that "FIELD" data is
;	actually "FILED" word.  not sure where or when that booboo occurred...
;
;Sun, Mar 21, 1999, 23:33
;added new words FFWRDG.hex w/ more to come...
;retrofit for version 3.xx.  Data bases reside at bank 3 of U4(lo).
;	words reside in u4hi.
;	bank0 = 0000 - 3fff
;	bank1 = 4000 - 7fff
;	bank2 = 8000 - bfff
;	bank3 = c000 - ffff
;fixed "0" flaw...any word with a ROM address of $0000 is ignored by SPEK 'cuz
;	$0000 is the NOP code for the data base.  Therefore, the 1st byte in the
;	ROM CANNOT be a word start.  Moved HICHR to 1st byte to eliminate
;	the problem.

TEXT_T	EQU SPKROM+{maxwords*2}+2
ALPHlst	EQU TEXT_T+$0C80		; leave room for alphalist

	ORG	SPKROM	; map $4000-$7fff to $C000-$ffff

WORD_2	FDB 0
	FDB REPETER	;1
	FDB OFF		;2
	FDB ON_		;3
	FDB METER		;4
	FDB MACHIN	;5
	FDB COMPLT	;6
	FDB THIS		;7
	FDB IS		;8
	FDB THE_		;9
	FDB DELTA		;A
	FDB 0		;B
	FDB WATTS		;C
	FDB 0		;D
	FDB CHANGE	;E
	FDB MINUS		;F
	FDB NOT		;10
	FDB STARTW	;11
	FDB LINE		;12
	FDB THOU		;13
	FDB TIME		;14
	FDB WAIT		;15
	FDB SMOKE		;16
	FDB ABORT		;17
	FDB HUND		;18
	FDB CALL		;19
	FDB 0		;1A
	FDB EQUAL		;1B
	FDB FAST		;1C
	FDB GO		;1D
	FDB LOW		;1E
	FDB OPEN		;1F
	FDB 0		;20
	FDB SET		;21
	FDB SPEED		;22
	FDB P		;23
	FDB OPRATR	;24
	FDB AMPS		;25
	FDB MEGA		;26
	FDB POWER		;27
	FDB TWENT		;28
	FDB ELEVN		;29
	FDB SIERRA	;2A
	FDB TWELV		;2B
	FDB 0		;2C	cw (,)
	FDB 0		;2D	cw (-)
	FDB 0		;2E	cw (.)
	FDB 0		;2F	cw (/)
	FDB ZERO		;30
	FDB ONE		;31
	FDB TWO		;32
	FDB THREE		;33
	FDB FOUR		;34
	FDB FIVE		;35
	FDB SIX		;36
	FDB SEVEN		;37
	FDB EIGHT		;38
	FDB NINE		;39
	FDB EXIT		;3A
	FDB PLUS		;3B
	FDB SHUT		;3C
	FDB 0		;3D	cw (=)
	FDB TIMER		;3E
	FDB 0		;3F	cw (?)
	FDB THIRT		;40
	FDB A		;41
	FDB B		;42
	FDB C		;43
	FDB D		;44
	FDB E		;45
	FDB F		;46
	FDB G		;47
	FDB H		;48
	FDB I		;49
	FDB J		;4A
	FDB K		;4B
	FDB L		;4C
	FDB M		;4D
	FDB N		;4E
	FDB O		;4F
	FDB P		;50
	FDB Q		;51
	FDB R		;52
	FDB S		;53
	FDB T		;54
	FDB U		;55
	FDB V		;56
	FDB W		;57
	FDB Xl		;58
	FDB Yl		;59
	FDB Z		;5A
	FDB ALERT		;5B
	FDB ADJST		;5C
	FDB FREQ		;5D
	FDB HIGH		;5E
	FDB OSCAR		;5F
	FDB AND		;60
	FDB CHECK		;61
	FDB SWITCH	;62
	FDB DOWN		;63
	FDB POINT		;64
	FDB BREAK		;65
	FDB ENTER		;66
	FDB FROM		;67
	FDB GET		;68
	FDB HOLD		;69
	FDB OF		;6A
	FDB PRESS		;6B
	FDB RANGE		;6C
	FDB TURN		;6D
	FDB BASE		;6E
	FDB EMGNCY	;6F
	FDB ANSWR		;70
	FDB READY		;71
	FDB ECHO		;72
	FDB CYCLE		;73
	FDB TEN		;74
	FDB CNTL		;75
	FDB AT		;76
	FDB ALL		;77
	FDB CANCEL	;78
	FDB TEST		;79
	FDB UP		;7A
	FDB FORT		;7B
	FDB SIXT		;7C
	FDB DEGRES	;7D
	FDB OUT		;7E
	FDB SEVENT	;7F
	FDB WOH		;80
	FDB WONE		;81
	FDB WTWO		;82
	FDB WTHREE	;83
	FDB WFOUR		;84
	FDB WFIVE		;85
	FDB WSIX		;86
	FDB WSEVEN	;87
	FDB WEIGHT	;88
	FDB WNINE		;89
	FDB WTHE		;8A
	FDB WTIME		;8B
	FDB WIS		;8C
	FDB WA_M		;8D
	FDB WP_M		;8E
	FDB WOCLK		;8F
	FDB WTEN		;90
	FDB W11		;91
	FDB W12		;92
	FDB W13		;93
	FDB W14		;94
	FDB W15		;95
	FDB W16		;96
	FDB W17		;97
	FDB W18		;98
	FDB W19		;99
	FDB W20		;9A
	FDB W30		;9B
	FDB W40		;9C
	FDB W50		;9D
	FDB WGOOD		;9E
	FDB WMORN		;9F
	FDB WAFTR		;A0
	FDB WEVENG	;A1
	FDB WEATH		;A2
	FDB TEMPERAT	;A3
	FDB TSTORM	;A4
	FDB SEVER		;A5
	FDB TORNAD	;A6
	FDB FIRE		;A7
	FDB ABOUT		;A8
	FDB ERROR		;A9
	FDB IN		;AA
	FDB OVER		;AB
	FDB PERCENT	;AC
	FDB KEY		;AD
	FDB PLEASE	;AE

	FDB 0		;AF	[S]
	FDB 0		;B0	[T]
	FDB 0		;B1	[DAY]
	FDB 0		;B2	[TC]
	FDB 0		;B3	[TF]
	FDB 0		;B4	[CW]
	FDB 0		;B5	[SP]
	FDB 0		;B6	[SPI]
	FDB 0		;B7	[CT]
	FDB 0		;B8	[PAG]
	FDB 0		;B9	[OUT]
	FDB 0		;BA	[LEV]
	FDB 0		;BB	[ETI]

	FDB EIGHTY	;BC
	FDB NINET		;BD
	FDB TEEN3		;BE
	FDB TEEN4		;BF
	FDB TEEN5		;C0
	FDB TEEN6		;C1
	FDB TEEN7		;C2
	FDB TEEN8		;C3
	FDB TEEN9		;C4
	FDB 0			;[POZ]
	FDB FIFT		;C6
	FDB MOVING	;C7
	FDB ING		;C8
	FDB ALPHA		;C9
	FDB BUTTON	;CA
	FDB DANGER	;CB
	FDB EAST		;CC
	FDB HOURS		;CD
	FDB KILO		;CE
	FDB MILLI		;CF
	FDB NOVEMBER	;D0
	FDB OHMS		;D1
	FDB NORTH		;D2
	FDB PRESSURE	;D3
	FDB REPAIR	;D4
	FDB RIGHT		;D5
	FDB LEFT		;D6
	FDB SOUTH		;D7
	FDB STOP		;D8
	FDB WHISKEY	;D9
	FDB XRAY		;DA
	FDB WEST		;DB
	FDB CURRENT	;DC
	FDB FARENHEIT	;DD
	FDB RED		;DE
	FDB STORM		;DF
	FDB THEE		;E0
	FDB VISABILITY	;E1
	FDB FAILURE	;E2
	FDB HOTEL		;E3
	FDB NEAR		;E4
	FDB GROUND	;E5
	FDB TELEPHONE	;E6
	FDB TOWER		;E7
	FDB AUTOMATIC	;E8
	FDB INFORMATION	;E9
	FDB NUMBER	;EA
	FDB SERVICE	;EB
	FDB SQUAWK	;EC
	FDB REPEAT	;ED
	FDB FEET		;EE
	FDB MEASURE	;EF
	FDB MILE		;F0
	FDB HERTZ		;F1
	FDB ICING		;F2
	FDB MAYDAY	;F3
	FDB MARKER	;F4
	FDB million	;F5
	FDB AT		;F6
	FDB 0		;F7
	FDB 0		;F8
	FDB 0		;F9
	FDB 0		;FA
	FDB 0		;FB
	FDB 0		;FC
	FDB 0		;FD
	FDB 0		;FE
	FDB 0	;FF
	FDB CLOCK		;100
	FDB MOVE		;101
	FDB BETWEEN	;102
	FDB BRAVO		;103
	FDB DIRECTION	;104
	FDB DISPLAY	;105
	FDB ELECTRICIAN	;106
	FDB FLOW		;107
	FDB FOXTROT	;108
	FDB GALLONS	;109
	FDB GATE		;10A
	FDB GUAGE		;10B
	FDB GOLF		;10C
	FDB HENRY		;10D
	FDB INCH		;10E
	FDB INTRUDER	;10F
	FDB JULIET	;110
	FDB LIMA		;111
	FDB MIKE		;112
	FDB MINUTES	;113
	FDB MOTOR		;114
	FDB PAPA		;115
	FDB PASS		;116
	FDB POSITION	;117
	FDB PROBE		;118
	FDB PULL		;119
	FDB PUSH		;11A
	FDB QUEBEC	;11B
	FDB CHARLIE	;11C
	FDB TANGO		;11D
	FDB UNDER		;11E
	FDB UNIFORM	;11F
	FDB YANKEE	;120
	FDB DAYS		;121
	FDB GREEN		;122
	FDB MANUAL	;123
	FDB INDIA		;124
	FDB VOLTS		;125
	FDB ROMEO		;126
	FDB VICTOR	;127
	FDB ZULU		;128
	FDB MICRO		;129
	FDB AREA		;12A
	FDB CIRCUIT	;12B
	FDB CONNECT	;12C
	FDB SECONDS	;12D
	FDB UNIT		;12E
	FDB DEVICE	;12F
	FDB SLOW		;130
	FDB TOOL		;131
	FDB CAUTION	;132
	FDB LIGHT		;133
	FDB VALVE		;134
	FDB CALIBRATE	;135
	FDB CRANE		;136
	FDB PASSED	;137
	FDB SAFE		;138
	FDB YELLOW	;139
	FDB DOOR		;13A
	FDB HALF		;
	FDB AFFIRMITIVE	;
	FDB DIVIDED	;
	FDB BY		;
	FDB WHITE		;
	FDB OCLOCK	;
	FDB CELSIUS	;
	FDB PER		;
	FDB DUST		;
	FDB HAIL		;
	FDB WIND		;
	FDB SHOWERS	;
	FDB SLEET		;
	FDB SNOW		;
	FDB SAND		;
	FDB RAIN		;
	FDB FOG		;
	FDB HEAVY		;
	FDB LAND		;
	FDB THIN		;
	FDB ICE		;
	FDB VARIABLE	;
	FDB BROKEN	;
	FDB CEILING	;
	FDB PARTIALLY	;
	FDB INDICATED	;
	FDB MODERATE	;
	FDB GREENWICH	;
	FDB MEAN		;
	FDB MIST		;
	FDB ESTIMATED	;
	FDB ALTERNATE	;
	FDB CLEAR		;
	FDB BLOWING	;
	FDB TURBULENCE	;
	FDB FREEZING	;
	FDB AIR		;
	FDB BELOW		;
	FDB HAZE		;
	FDB SCATTERED	;
	FDB UNLIMITED	;
	FDB ALOFT		;
	FDB GLIDE		;
	FDB FIELD		;
	FDB KNOTS		;
	FDB ACTION	;
	FDB PATH		;
	FDB DECREASE	;
	FDB ADVISE	;
	FDB HAVE		;
	FDB NO		;
	FDB IMMEADIATELY	;
	FDB FINAL		;
	FDB COURSE	;
	FDB RADAR		;
	FDB OTHER		;
	FDB OIL		;
	FDB MUCH		;
	FDB CONTACT	;
	FDB FUEL		;
	FDB LEVEL		;
	FDB LONG		;
	FDB CLOSED	;
	FDB EVACUATE	;
	FDB IDENTIFY	;
	FDB CENTER	;
	FDB GRAIN		;
	FDB EXPECT	;
	FDB PLAN		;
	FDB AERIAL	;
	FDB ENGINE	;
	FDB INBOUND	;
	FDB IGNITE	;
	FDB CABIN		;
	FDB ARRIVAL	;
	FDB ACKNOW	;
	FDB RAISE		;
	FDB APPROACH	;
	FDB IDLE		;
	FDB INCREASE	;
	FDB AS		;
	FDB ABOVE		;
	FDB CALM		;
	FDB CRYSTALS	;
	FDB FULL		;
	FDB NEW		;
	FDB LEG		;
	FDB MAINTAIN	;
	FDB LEAN		;
	FDB SHORT		;
	FDB WAKE		;
	FDB HEADING	;
	FDB LAUNCH	;
	FDB STALL		;
	FDB TOUCHDOWN	;
	FDB CLIMB		;
	FDB BANK		;
	FDB ACCELERATED	;
	FDB TRIM		;
	FDB SLOPE		;
	FDB NINER		;
	FDB FREEDOM	;
	FDB FLIGHT	;
	FDB ALTITUDE	;
	FDB REMARK	;
	FDB OUTER		;
	FDB MIDDLE	;
	FDB INNER		;
	FDB INSTRUMENT	;
	FDB GEAR		;
	FDB BOOST		;
	FDB LIST		;
	FDB RECEIVE	;
	FDB TRANSMIT	;
	FDB AMATEUR
	FDB BAND
	FDB CLUB
	FDB CODE
	FDB COME
	FDB FRIDAY
	FDB HAM
	FDB HAMVENTION
	FDB HAMFEST
	FDB IT
	FDB LINK
	FDB MEETING
	FDB MONDAY
	FDB NET
	FDB NEXT
	FDB NIGHT
	FDB REMOTE
	FDB SATURDAY
	FDB SUNDAY
	FDB THAT
	FDB THURSDAY
	FDB TODAY
	FDB TOMORROW
	FDB TONIGHT
	FDB TUESDAY
	FDB USEE
	FDB USE_
	FDB VERIFY
	FDB 0
	FDB WARNING
	FDB WATCH
	FDB WEDNESDAY
	FDB WELCOME
	FDB WILL
	FDB WITH
	FDB YESTERDAY
	FDB YOUR
	FDB ZED
;REPEATER
	FDB GAZOO
	FDB advanced
	FDB april
	FDB august
	FDB auto
	FDB auxilliary
	FDB battery
	FDB board
	FDB calling
	FDB computer
	FDB condition
	FDB congrats
	FDB count
	FDB dayton
	FDB december
	FDB departure
	FDB dial
	FDB dinner
	FDB drive
	FDB _ed
	FDB _er
	FDB evacuation
	FDB elevation
	FDB fail
	FDB february
	FDB first
	FDB fourth
	FDB front
	FDB hazardous
	FDB help
	FDB home
	FDB hour
	FDB july
	FDB june
	FDB landing
	FDB late
	FDB lessthan
	FDB lock
	FDB look
	FDB lower
	FDB lunch
	FDB march
	FDB may
	FDB me
	FDB messages
	FDB miles
	FDB mobile
	FDB month
	FDB morethan
	FDB negative
	FDB october
	FDB ohio
	FDB operation
	FDB patch
	FDB phone
	FDB police
	FDB practice
	FDB private
	FDB programming
	FDB radio
	FDB rate
	FDB rear
	FDB release
	FDB rich
	FDB rig
	FDB road
	FDB roger
	FDB route
	FDB _s
	FDB second
	FDB security
	FDB select
	FDB september
	FDB sequence
	FDB sexy
	FDB side
	FDB sight
	FDB system
	FDB tank
	FDB target
	FDB terminal
	FDB thankyou
	FDB third
	FDB until
	FDB valley
	FDB way
	FDB wrong
	FDB you
	FDB zone
	FDB january
	FDB _teen
	FDB _th
	FDB _ty
	FDB fif_
	FDB thir_
	FDB thisis
	FDB a_m_
	FDB p_m_
	FDB decreasing
	FDB increasingto
	FDB to
	FDB traffic
	FDB converging
	FDB filed
	FDB for
	FDB inspector
	FDB santaclara
	FDB spray
	FDB taxi
	FDB january
	FDB february
	FDB march
	FDB april
	FDB june
	FDB july
	FDB august
	FDB september
	FDB october
	FDB NOVEMBER
	FDB december
	FDB MONDAY
	FDB TUESDAY
	FDB WEDNESDAY
	FDB THURSDAY
	FDB FRIDAY
	FDB SATURDAY
	FDB SUNDAY
	FDB OVERIDE

	ORG	TEXT_T

;start of text xref ^^^ <--these are to sync the word sort utility...

	FCB $80			;0
	FCB "REPEATE","R"+$80	;1
	FCB "OF","F"+$80		;2
	FCB "O","N"+$80		;3
	FCB "METE","R"+$80		;4
	FCB "MACHIN","E"+$80	;5
	FCB "COMPLET","E"+$80	;6
	FCB "THI","S"+$80		;7
	FCB "I","S"+$80		;8
	FCB "TH","E"+$80		;9
	FCB "DELT","A"+$80		;A
	FCB "[ID","]"+$80		;B	call phrase
	FCB "WATT","S"+$80		;C
	FCB $80			;D	cr (eol)
	FCB "CHANG","E"+$80		;E
	FCB "MINU","S"+$80		;F
	FCB "NO","T"+$80		;10
	FCB "STAR","T"+$80		;11
	FCB "LIN","E"+$80		;12
	FCB "100","0"+$80		;13
	FCB "TIM","E"+$80		;14
	FCB "WAI","T"+$80		;15
	FCB "SMOK","E"+$80		;16
	FCB "ABOR","T"+$80		;17
	FCB "10","0"+$80		;18
	FCB "CAL","L"+$80		;19
	FCB $80			;1A	eof
	FCB "EQUA","L"+$80		;1B
	FCB "FAS","T"+$80		;1C
	FCB "G","O"+$80		;1D
	FCB "LO","W"+$80		;1E
	FCB "OPE","N"+$80		;1F
	FCB "_"+$80		;20	cw (pause)
	FCB "SE","T"+$80		;21
	FCB "SPEE","D"+$80		;22
	FCB "#"+$80		;23
	FCB "OPERATO","R"+$80	;24
	FCB "AMP","S"+$80		;25
	FCB "MEG","A"+$80		;26
	FCB "POWE","R"+$80		;27
	FCB "2","0"+$80		;28
	FCB "1","1"+$80		;29
	FCB "SIERR","A"+$80		;2A
	FCB "1","2"+$80		;2B
	FCB ","+$80		;2C	cw (,)
	FCB "-"+$80		;2D	cw (-)
	FCB "."+$80		;2E	cw (.)
	FCB "/"+$80		;2F	cw (/)
	FCB "0"+$80		;30
	FCB "1"+$80		;31
	FCB "2"+$80		;32
	FCB "3"+$80		;33
	FCB "4"+$80		;34
	FCB "5"+$80		;35
	FCB "6"+$80		;36
	FCB "7"+$80		;37
	FCB "8"+$80		;38
	FCB "9"+$80		;39
	FCB "EXI","T"+$80		;3A
	FCB "PLU","S"+$80		;3B
	FCB "SHU","T"+$80		;3C
	FCB "="+$80		;3D	cw (=)
	FCB "TIME","R"+$80		;3E
	FCB "?"+$80		;3F	cw (?)
	FCB "3","0"+$80		;40
	FCB "A"+$80		;41
	FCB "B"+$80		;42
	FCB "C"+$80		;43
	FCB "D"+$80		;44
	FCB "E"+$80		;45
	FCB "F"+$80		;46
	FCB "G"+$80		;47
	FCB "H"+$80		;48
	FCB "I"+$80		;49
	FCB "J"+$80		;4A
	FCB "K"+$80		;4B
	FCB "L"+$80		;4C
	FCB "M"+$80		;4D
	FCB "N"+$80		;4E
	FCB "O"+$80		;4F
	FCB "P"+$80		;50
	FCB "Q"+$80		;51
	FCB "R"+$80		;52
	FCB "S"+$80		;53
	FCB "T"+$80		;54
	FCB "U"+$80		;55
	FCB "V"+$80		;56
	FCB "W"+$80		;57
	FCB "X"+$80		;58
	FCB "Y"+$80		;59
	FCB "Z"+$80		;5A
	FCB "ALER","T"+$80		;5B
	FCB "ADJUS","T"+$80		;5C
	FCB "FREQUEN","C"+$80	;5D
	FCB "HIG","H"+$80		;5E
	FCB "OSCA","R"+$80		;5F
	FCB "AN","D"+$80		;60
	FCB "CHEC","K"+$80		;61
	FCB "SWITC","H"+$80		;62
	FCB "DOW","N"+$80		;63
	FCB "POIN","T"+$80		;64
	FCB "BREA","K"+$80		;65
	FCB "ENTE","R"+$80		;66
	FCB "FRO","M"+$80		;67
	FCB "GE","T"+$80		;68
	FCB "HOL","D"+$80		;69
	FCB "O","F"+$80		;6A
	FCB "PRES","S"+$80		;6B
	FCB "RANG","E"+$80		;6C
	FCB "TUR","N"+$80		;6D
	FCB "BAS","E"+$80		;6E
	FCB "EMERGEN","C"+$80	;6F
	FCB "ANSWE","R"+$80		;70
	FCB "READ","Y"+$80		;71
	FCB "ECH","O"+$80		;72
	FCB "CYCL","E"+$80		;73
	FCB "1","0"+$80		;74
	FCB "CONTRO","L"+$80	;75
	FCB "A","T"+$80		;76
	FCB "AL","L"+$80		;77
	FCB "CANCE","L"+$80		;78
	FCB "TES","T"+$80		;79
	FCB "U","P"+$80		;7A
	FCB "4","0"+$80		;7B
	FCB "6","0"+$80		;7C
	FCB "DEGREE","S"+$80	;7D
	FCB "OU","T"+$80		;7E
	FCB "7","0"+$80		;7F
	FCB "F","0"+$80		;80
	FCB "F","1"+$80		;81
	FCB "F","2"+$80		;82
	FCB "F","3"+$80		;83
	FCB "F","4"+$80		;84
	FCB "F","5"+$80		;85
	FCB "F","6"+$80		;86
	FCB "F","7"+$80		;87
	FCB "F","8"+$80		;88
	FCB "F","9"+$80		;89
	FCB "FTH","E"+$80		;8A
	FCB "FTIM","E"+$80		;8B
	FCB "FI","S"+$80		;8C
	FCB "FA","M"+$80		;8D
	FCB "FP","M"+$80		;8E
	FCB "FOCLOC","K"+$80	;8F
	FCB "F1","0"+$80		;90
	FCB "F1","1"+$80		;91
	FCB "F1","2"+$80		;92
	FCB "F1","3"+$80		;93
	FCB "F1","4"+$80		;94
	FCB "F1","5"+$80		;95
	FCB "F1","6"+$80		;96
	FCB "F1","7"+$80		;97
	FCB "F1","8"+$80		;98
	FCB "F1","9"+$80		;99
	FCB "F2","0"+$80		;9A
	FCB "F3","0"+$80		;9B
	FCB "F4","0"+$80		;9C
	FCB "F5","0"+$80		;9D
	FCB "FGOO","D"+$80		;9E
	FCB "FMORNIN","G"+$80	;9F
	FCB "FAFTERN","O"+$80	;A0
	FCB "FEVENIN","G"+$80	;A1
	FCB "WEATHE","R"+$80	;A2
	FCB "TEMPERA","T"+$80	;A3
	FCB "TSTOR","M"+$80		;A4
	FCB "SEVER","E"+$80		;A5
	FCB "TORNAD","O"+$80	;A6
	FCB "FIR","E"+$80		;A7
	FCB "ABOU","T"+$80		;A8
	FCB "ERRO","R"+$80		;A9
	FCB "I","N"+$80		;AA
	FCB "OVE","R"+$80		;AB
	FCB "PERCEN","T"+$80	;AC
	FCB "KE","Y"+$80		;AD
	FCB "PLEAS","E"+$80		;AE

	FCB "[S","]"+$80		;AF	[S]	salutation primative
	FCB "[T","]"+$80		;B0	[T]	time of day primative
	FCB "[DAY","]"+$80		;B1	[DAY]	day primative
	FCB "[TC","]"+$80		;B2	[TC]	deg C primative
	FCB "[TF","]"+$80		;B3	[TF]	deg F primative
	FCB "[CW","]"+$80		;B4	[CW]	cw phrase macro
	FCB "[SP","]"+$80		;B5	[SP]	speech revert macro
	FCB "[SPI","]"+$80		;B6	[SPI]	fn out (ie, dvr exec)
	FCB "[CT","]"+$80		;B7	[CT]	ct revert macro
	FCB "[PAG","]"+$80		;B8	[PAG]	pager tone send (reed1+reed2)
	FCB "[OUT","]"+$80		;B9	[OUT]	output set/clear
	FCB "[LEV","]"+$80		;BA	[LEV]	change speech level
	FCB "[ETI","]"+$80		;BB	[ETI]	speak ETI in hrs/min

	FCB "8","0"+$80		;BC
	FCB "9","0"+$80		;BD
	FCB "1","3"+$80		;BE
	FCB "1","4"+$80		;BF
	FCB "1","5"+$80		;C0
	FCB "1","6"+$80		;C1
	FCB "1","7"+$80		;C2
	FCB "1","8"+$80		;C3
	FCB "1","9"+$80		;C4
	FCB "[POZ","]"+$80		;C5	[POZ]	wait for input # 4 = low
	FCB "5","0"+$80		;C6
	FCB "MOVIN","G"+$80		;C7
	FCB "_IN","G"+$80		;C8
	FCB "ALPH","A"+$80		;C9
	FCB "BUTTO","N"+$80		;CA
	FCB "DANGE","R"+$80		;CB
	FCB "EAS","T"+$80		;CC
	FCB "HOUR","S"+$80		;CD
	FCB "KIL","O"+$80		;CE
	FCB "MILL","I"+$80		;CF
	FCB "NOVEMBE","R"+$80	;D0
	FCB "OHM","S"+$80		;D1
	FCB "NORT","H"+$80		;D2
	FCB "PRESSUR","E"+$80	;D3
	FCB "REPAI","R"+$80		;D4
	FCB "RIGH","T"+$80		;D5
	FCB "LEF","T"+$80		;D6
	FCB "SOUT","H"+$80		;D7
	FCB "STO","P"+$80		;D8
	FCB "WHISKE","Y"+$80	;D9
	FCB "XRA","Y"+$80		;DA
	FCB "WES","T"+$80		;DB
	FCB "CURREN","T"+$80	;DC
	FCB "FARENHE","I"+$80	;DD
	FCB "RE","D"+$80		;DE
	FCB "STOR","M"+$80		;DF
	FCB "THE","E"+$80		;E0
	FCB "VISIBIL","I"+$80	;E1
	FCB "FAILUR","E"+$80	;E2
	FCB "HOTE","L"+$80		;E3
	FCB "NEA","R"+$80		;E4
	FCB "GROUN","D"+$80		;E5
	FCB "TELEPHO","N"+$80	;E6
	FCB "TOWE","R"+$80		;E7
	FCB "AUTOMAT","I"+$80	;E8
	FCB "INFORMA","T"+$80	;E9
	FCB "NUMBE","R"+$80		;EA
	FCB "SERVIC","E"+$80	;EB
	FCB "SQUAW","K"+$80		;EC
	FCB "REPEA","T"+$80		;ED
	FCB "FEE","T"+$80		;EE
	FCB "MEASUR","E"+$80	;EF
	FCB "MIL","E"+$80		;F0
	FCB "HERT","Z"+$80		;F1
	FCB "ICIN","G"+$80		;F2
	FCB "MAYDA","Y"+$80		;F3
	FCB "MARKE","R"+$80		;F4
	FCB "1E","6"+$80		;F5
	FCB "@"+$80		;F6	new CW @ code
	FCB $80			;F7
	FCB $80			;F8
	FCB $80			;F9
	FCB $80			;FA
	FCB $80			;FB
	FCB $80			;FC
	FCB $80			;FD	spwbank3 prefix
	FCB "XTR","A"+$80		;FE
	FCB $80			;FF	spwbank2 prefix
	FCB "CLOC","K"+$80		;100	bank 2 words...
	FCB "MOV","E"+$80		;101
	FCB "BETWEE","N"+$80	;102
	FCB "BRAV","O"+$80		;103
	FCB "DIREC","T"+$80		;104
	FCB "DISPLA","Y"+$80	;105
	FCB "ELECTRI","C"+$80	;106
	FCB "FLO","W"+$80		;107
	FCB "FOXTRO","T"+$80	;108
	FCB "GALLO","N"+$80		;109
	FCB "GAT","E"+$80		;10A
	FCB "GUAG","E"+$80		;10B
	FCB "GOL","F"+$80		;10C
	FCB "HENR","Y"+$80		;10D
	FCB "INC","H"+$80		;10E
	FCB "INTRUDE","R"+$80	;10F
	FCB "JULIE","T"+$80		;110
	FCB "LIM","A"+$80		;111
	FCB "MIK","E"+$80		;112
	FCB "MINUT","E"+$80		;113
	FCB "MOTO","R"+$80		;114
	FCB "PAP","A"+$80		;115
	FCB "PAS","S"+$80		;116
	FCB "POSITIO","N"+$80	;117
	FCB "PROB","E"+$80		;118
	FCB "PUL","L"+$80		;119
	FCB "PUS","H"+$80		;11A
	FCB "QUEBE","C"+$80		;11B
	FCB "CHARLI","E"+$80	;11C
	FCB "TANG","O"+$80		;11D
	FCB "UNDE","R"+$80		;11E
	FCB "UNIFOR","M"+$80	;11F
	FCB "YANKE","E"+$80		;120
	FCB "DAY","S"+$80		;121
	FCB "GREE","N"+$80		;122
	FCB "MANUA","L"+$80		;123
	FCB "INDI","A"+$80		;124
	FCB "VOLT","S"+$80		;125
	FCB "ROME","O"+$80		;126
	FCB "VICTO","R"+$80		;127
	FCB "ZUL","U"+$80		;128
	FCB "MICR","O"+$80		;129
	FCB "ARE","A"+$80		;12A
	FCB "CIRCUI","T"+$80	;12B
	FCB "CONNEC","T"+$80	;12C
	FCB "SECOND","S"+$80	;12D
	FCB "UNI","T"+$80		;12E
	FCB "DEVIC","E"+$80		;12F
	FCB "SLO","W"+$80		;130
	FCB "TOO","L"+$80		;131
	FCB "CAUTIO","N"+$80	;132
	FCB "LIGH","T"+$80		;133
	FCB "VALV","E"+$80		;134
	FCB "CALIBRA","T"+$80	;135
	FCB "CRAN","E"+$80		;136
	FCB "PASSE","D"+$80		;137
	FCB "SAF","E"+$80		;138
	FCB "YELLO","W"+$80		;139
	FCB "DOO","R"+$80		;13A
	FCB "HAL","F"+$80		;13B
	FCB "AFFIRMA","T"+$80	;13C
	FCB "DIVID","E"+$80		;13D
	FCB "B","Y"+$80		;13E
	FCB "WHIT","E"+$80		;13F
	FCB "OCLOC","K"+$80		;140
	FCB "CELSIU","S"+$80	;141
	FCB "PE","R"+$80		;142
	FCB "DUS","T"+$80		;143
	FCB "HAI","L"+$80		;144
	FCB "WIN","D"+$80		;145
	FCB "SHOWE","R"+$80		;146
	FCB "SLEE","T"+$80		;147
	FCB "SNO","W"+$80		;148
	FCB "SAN","D"+$80		;149
	FCB "RAI","N"+$80		;14A
	FCB "FO","G"+$80		;14B
	FCB "HEAV","Y"+$80		;14C
	FCB "LAN","D"+$80		;14D
	FCB "THI","N"+$80		;14E
	FCB "IC","E"+$80		;14F
	FCB "VARIABL","E"+$80	;150
	FCB "BROKE","N"+$80		;151
	FCB "CEILIN","G"+$80	;152
	FCB "PARTIAL","L"+$80	;153
	FCB "INDICAT","E"+$80	;154
	FCB "MODERAT","E"+$80	;155
	FCB "GRENWHI","C"+$80	;156
	FCB "MEA","N"+$80		;157
	FCB "MIS","T"+$80		;158
	FCB "ESTIMAT","E"+$80	;159
	FCB "ALTERNA","T"+$80	;15A
	FCB "CLEA","R"+$80		;15B
	FCB "BLOWIN","G"+$80	;15C
	FCB "TURBULE","N"+$80	;15D
	FCB "FREEZ","E"+$80		;15E
	FCB "AI","R"+$80		;15F
	FCB "BELO","W"+$80		;160
	FCB "HAZ","E"+$80		;161
	FCB "SCATTER","E"+$80	;162
	FCB "UNLIMIT","E"+$80	;163
	FCB "ALOF","T"+$80		;164
	FCB "GLID","E"+$80		;165
	FCB "FIEL","D"+$80		;166
	FCB "KNOT","S"+$80		;167
	FCB "ACTIO","N"+$80		;168
	FCB "PAT","H"+$80		;169
	FCB "DECREAS","E"+$80	;16A
	FCB "ADVIS","E"+$80		;16B
	FCB "HAV","E"+$80		;16C
	FCB "N","O"+$80		;16D
	FCB "IMMEADI","A"+$80	;16E
	FCB "FINA","L"+$80		;16F
	FCB "COURS","E"+$80		;170
	FCB "RADA","R"+$80		;171
	FCB "OTHE","R"+$80		;172
	FCB "OI","L"+$80		;173
	FCB "MUC","H"+$80		;174
	FCB "CONTAC","T"+$80	;175
	FCB "FUE","L"+$80		;176
	FCB "LEVE","L"+$80		;177
	FCB "LON","G"+$80		;178
	FCB "CLOS","E"+$80		;179
	FCB "EVACUAT","E"+$80	;17A
	FCB "IDENTIF","Y"+$80	;17B
	FCB "CENTE","R"+$80		;17C
	FCB "GRAI","N"+$80		;17D
	FCB "EXPEC","T"+$80		;17E
	FCB "PLA","N"+$80		;17F
	FCB "AERIA","L"+$80		;180
	FCB "ENGIN","E"+$80		;181
	FCB "INBOUN","D"+$80	;182
	FCB "IGNIT","E"+$80		;183
	FCB "CABI","N"+$80		;184
	FCB "ARRIVA","L"+$80	;185
	FCB "ACKNOWL","E"+$80	;186
	FCB "RAIS","E"+$80		;187
	FCB "APPROAC","H"+$80	;188
	FCB "IDL","E"+$80		;189
	FCB "INCREAS","E"+$80	;18A
	FCB "A","S"+$80		;18B
	FCB "ABOV","E"+$80		;18C
	FCB "CAL","M"+$80		;18D
	FCB "CRYSTA","L"+$80	;18E
	FCB "FUL","L"+$80		;18F
	FCB "NE","W"+$80		;190
	FCB "LE","G"+$80		;191
	FCB "MAINTAI","N"+$80	;192
	FCB "LEA","N"+$80		;193
	FCB "SHOR","T"+$80		;194
	FCB "WAK","E"+$80		;195
	FCB "HEADIN","G"+$80	;196
	FCB "LAUNC","H"+$80		;197
	FCB "STAL","L"+$80		;198
	FCB "TOUCHDO","W"+$80	;199
	FCB "CLIM","B"+$80		;19A
	FCB "BAN","K"+$80		;19B
	FCB "ACCELER","A"+$80	;19C
	FCB "TRI","M"+$80		;19D
	FCB "SLOP","E"+$80		;19E
	FCB "NINE","R"+$80		;19F
	FCB "FREEDO","M"+$80	;1A0
	FCB "FLIGH","T"+$80		;1A1
	FCB "ALTITUD","E"+$80	;1A2
	FCB "REMAR","K"+$80		;1A3
	FCB "OUTE","R"+$80		;1A4
	FCB "MIDDL","E"+$80		;1A5
	FCB "INNE","R"+$80		;1A6
	FCB "INSTRUM","E"+$80	;1A7
	FCB "GEA","R"+$80		;1A8
	FCB "BOOS","T"+$80		;1A9
	FCB "LIS","T"+$80		;1AA
	FCB "RECEIV","E"+$80	;1AB
	FCB "TRANSMI","T"+$80	;1AC
	FCB "AMATEU","R"+$80	;1AD
	FCB "BAN","D"+$80		;1AE
	FCB "CLU","B"+$80		;1AF
	FCB "COD","E"+$80		;1B0
	FCB "COM","E"+$80		;1B1
	FCB "FRIDA","Y"+$80		;1B2
	FCB "HA","M"+$80		;1B3
	FCB "HAMVENT","I"+$80	;1B4
	FCB "HAMFES","T"+$80	;1B5
	FCB "I","T"+$80		;1B6
	FCB "LIN","K"+$80		;1B7
	FCB "MEETIN","G"+$80	;1B8
	FCB "MONDA","Y"+$80		;1B9
	FCB "NE","T"+$80		;1BA
	FCB "NEX","T"+$80		;1BB
	FCB "NIGH","T"+$80		;1BC
	FCB "REMOT","E"+$80		;1BD
	FCB "SATURDA","Y"+$80	;1BE
	FCB "SUNDA","Y"+$80		;1BF
	FCB "THA","T"+$80		;1C0
	FCB "THURSDA","Y"+$80	;1C1
	FCB "TODA","Y"+$80		;1C2
	FCB "TOMORRO","W"+$80	;1C3
	FCB "TONIGH","T"+$80	;1C4
	FCB "TUESDA","Y"+$80	;1C5
	FCB "USE","E"+$80		;1C6
	FCB "US","E"+$80		;1C7
	FCB "VERIF","Y"+$80		;1C8
	FCB $80			;1C9
	FCB "WARNIN","G"+$80	;1CA
	FCB "WATC","H"+$80		;1CB
	FCB "WEDNESD","A"+$80	;1CC
	FCB "WELCOM","E"+$80	;1CD
	FCB "WIL","L"+$80		;1CE
	FCB "WIT","H"+$80		;1CF
	FCB "YESTERD","A"+$80	;1D0
	FCB "YOU","R"+$80		;1D1
	FCB "ZE","D"+$80		;1D2
;REPEATER
	FCB "RPT","R"+$80		;1D3

	FCB "ADVANCE","D"+$80	;1D4
	FCB "APRI","L"+$80		;1D5
	FCB "AUGUS","T"+$80		;1D6
	FCB "AUT","O"+$80		;1D7
	FCB "AUXILLI","A"+$80	;1D8
	FCB "BATTER","Y"+$80	;1D9
	FCB "BOAR","D"+$80		;1DA
	FCB "CALLIN","G"+$80	;1DB
	FCB "COMPUTE","R"+$80	;1DC
	FCB "CONDITI","O"+$80	;1DD
	FCB "CONGRAT","U"+$80	;1DE
	FCB "COUN","T"+$80		;1DF
	FCB "DAYTO","N"+$80		;1E0
	FCB "DECEMBE","R"+$80	;1E1
	FCB "DEPARTU","R"+$80	;1E2
	FCB "DIA","L"+$80		;1E3
	FCB "DINNE","R"+$80		;1E4
	FCB "DRIV","E"+$80		;1E5
	FCB "_E","D"+$80		;1E6
	FCB "_E","R"+$80		;1E7
	FCB "EVACUAT","E"+$80	;1E8
	FCB "ELEVATI","O"+$80	;1E9
	FCB "FAI","L"+$80		;1EA
	FCB "FEBRUAR","Y"+$80	;1EB
	FCB "FIRS","T"+$80		;1EC
	FCB "FOURT","H"+$80		;1ED
	FCB "FRON","T"+$80		;1EE
	FCB "HAZARDO","U"+$80	;1EF
	FCB "HEL","P"+$80		;1F0
	FCB "HOM","E"+$80		;1F1
	FCB "HOU","R"+$80		;1F2
	FCB "JUL","Y"+$80		;1F3
	FCB "JUN","E"+$80		;1F4
	FCB "LANDIN","G"+$80	;1F5
	FCB "LAT","E"+$80		;1F6
	FCB "LESSTHA","N"+$80	;1F7
	FCB "LOC","K"+$80		;1F8
	FCB "LOO","K"+$80		;1F9
	FCB "LOWE","R"+$80		;1FA
	FCB "LUNC","H"+$80		;1FB
	FCB "MARC","H"+$80		;1FC
	FCB "MA","Y"+$80		;1FD
	FCB "M","E"+$80		;1FE
	FCB "MESSAGE","S"+$80	;1FF
	FCB "MILE","S"+$80		;200
	FCB "MOBIL","E"+$80		;201
	FCB "MONT","H"+$80		;202
	FCB "MORETHA","N"+$80	;203
	FCB "NEGATIV","E"+$80	;204
	FCB "OCTOBE","R"+$80	;205
	FCB "OHI","O"+$80		;206
	FCB "OPERATI","O"+$80	;207
	FCB "PATC","H"+$80		;208
	FCB "PHON","E"+$80		;209
	FCB "POLIC","E"+$80		;20A
	FCB "PRACTIC","E"+$80	;20B
	FCB "PRIVAT","E"+$80	;20C
	FCB "PROGRA","M"+$80	;20D
	FCB "RADI","O"+$80		;20E
	FCB "RAT","E"+$80		;20F
	FCB "REA","R"+$80		;210
	FCB "RELEAS","E"+$80	;211
	FCB "RIC","H"+$80		;212
	FCB "RI","G"+$80		;213
	FCB "ROA","D"+$80		;214
	FCB "ROGE","R"+$80		;215
	FCB "ROUT","E"+$80		;216
	FCB "_","S"+$80		;217
	FCB "SECON","D"+$80		;218
	FCB "SECURIT","Y"+$80	;219
	FCB "SELEC","T"+$80		;21A
	FCB "SEPTEMB","E"+$80	;21B
	FCB "SEQUENC","E"+$80	;21C
	FCB "SEX","Y"+$80		;21D
	FCB "SID","E"+$80		;21E
	FCB "SIGH","T"+$80		;21F
	FCB "SYSTE","M"+$80		;220
	FCB "TAN","K"+$80		;221
	FCB "TARGE","T"+$80		;222
	FCB "TERMINA","L"+$80	;223
	FCB "THANKYO","U"+$80	;224
	FCB "THIR","D"+$80		;225
	FCB "UNTI","L"+$80		;226
	FCB "VALLE","Y"+$80		;227
	FCB "WA","Y"+$80		;228
	FCB "WRON","G"+$80		;229
	FCB "YO","U"+$80		;22A
	FCB "ZON","E"+$80		;22B
	FCB "JANUAR","Y"+$80	;22C
	FCB "_TEE","N"+$80		;22D
	FCB "_T","H"+$80		;22E
	FCB "_T","Y"+$80		;22F
	FCB "FIF","_"+$80		;230
	FCB "THIR","_"+$80		;231
	FCB "THISI","S"+$80		;232
	FCB "A","M"+$80		;233
	FCB "P","M"+$80		;234
	FCB "DECREAS","N"+$80	;235
	FCB "INC","2"+$80	;236
	FCB "T","O"+$80		;237
	FCB "TRAFFI","C"+$80	;238
	FCB "CONVERG","I"+$80	;239
	FCB "FILE","D"+$80		;23A
	FCB "FO","R"+$80		;23B
	FCB "INSPECT","O"+$80	;23C
	FCB "SANTACL","A"+$80	;23D
	FCB "SPRA","Y"+$80		;23E
	FCB "TAX","I"+$80		;23F
	FCB "JA","N"+$80		;240
	FCB "FE","B"+$80		;241
	FCB "MA","R"+$80		;242
	FCB "AP","R"+$80		;243
	FCB "JU","N"+$80		;244
	FCB "JU","L"+$80		;245
	FCB "AU","G"+$80		;246
	FCB "SE","P"+$80		;247
	FCB "OC","T"+$80		;248
	FCB "NO","V"+$80		;249
	FCB "DE","C"+$80		;24a
	FCB "MO","N"+$80		;24b
	FCB "TU","E"+$80		;24c
	FCB "WE","D"+$80		;24d
	FCB "TH","U"+$80		;24e
	FCB "FR","I"+$80		;24f
	FCB "SA","T"+$80		;250
	FCB "SU","N"+$80		;251
	FCB "OVERID","E"+$80	;252

	FCB $FF

HICHR	EQU $253			; last word# + 1

	ORG	ALPHlst
	; pre-compiled alphabetical word listing
	FDB	$FF01	; caption#1
		; a
	FDB	65,23,168,396,412,390,360,92,468,363,384
	FDB	316,351,91,119,356,201,346,418,563,429
	FDB	37,96,112,392,579,469,298,389,395,118,582
	FDB	470,471,232,472
	FDB	$FF00	; caption#0
		; b
	FDB	66,430,411,110,473,352,258,348,474,425,259,101
	FDB	337,202,318
	FDB	$FF00	; caption#0
		; c
	FDB	67,388,309,25,475,397,120,306,338,321,380,14,284
	FDB	97,299,347,410,256,377,431,432,433,6,476,477,478
	FDB	300,373,117,569,479,368,310,398,220,115
	FDB	$FF00	; caption#0
		; d
	FDB	68,203,289,480,586,481,362,565,125,10,482,303,483
	FDB	484,260,261,317,314,99,485,323
	FDB	$FF00	; caption#0
		; e
	FDB	69,204,114,262,489,111,385,102,27,169,345,488,378
	FDB	58,382
	FDB	$FF00	; caption#0
		; f
	FDB	70,490,226,221,28,577,491,238,358,560,570,367,167
	FDB	492,140,417,263,331,571,493,264,416,350,93,591,434
	FDB	103,494,374,399
	FDB	$FF00	; caption#0
		; g
	FDB	71,265,266,424,104,357,29,268,381,290,342,229,267
	FDB	$FF00	; caption#0
		; h
	FDB	72,324,315,435,437,436,364,495,353,406,332,496
	FDB	269,241,94,105,497,227,498,205
	FDB	$FF00	; caption#0
		; i
	FDB	73,335,242,379,393,387,366,170,386,566,270,394,292
	FDB	340,233,422,572,423,271,8,438
	FDB	$FF00	; caption#0
		; j
	FDB	74,576,556,581,272,499,580,500
	FDB	$FF00	; caption#0
		; k
	FDB	75,173,206,359
	FDB	$FF00	; caption#0
		; l
	FDB	76,333,501,502,407,403,214,401,503,375,307,273,18
	FDB	439,426,504,376,505,30,506,507
	FDB	$FF00	; caption#0
		; m
	FDB	77,5,402,291,578,508,244,509,243,510,343,239,440
	FDB	38,511,4,297,421,274,240,512,207,15,275,344,513
	FDB	341,587,441,514,515,276,257,199,372
	FDB	$FF00	; caption#0
		; n
	FDB	78,228,516,442,400,443,444,415,365,210,16,585
	FDB	208,234
	FDB	$FF00	; caption#0
		; o
	FDB	79,320,584,517,106,2,518,209,371,3,31,519,36,95
	FDB	370,126,420,171,$252
	FDB	$FF00	; caption#0
		; p
	FDB	80,277,339,278,311,520,361,322,172,521,383,174,59
	FDB	564,100,522,279,39,523,107,211,524,280,525,281,282
	FDB	39,107,211,280,281,282
	FDB	$FF00	; caption#0
		; q
	FDB	81,283
	FDB	$FF00	; caption#0
		; r
	FDB	82,369,526,330,391,108,527,113,528,427,222,529,419
	FDB	445,212,237,1,530,531,213,532,533,294,534,467
	FDB	$FF00	; caption#0
		; s
	FDB	83,312,329,573,592,446,354,536,301,537,538,583,539
	FDB	540,235,33,165,541,404,326,60,542,42,543,327,414
	FDB	304,22,328,215,34,574,236,408,17,216,223,593,447
	FDB	98,544
	FDB	$FF00	; caption#0
		; t
	FDB	84,285,545,546,575,230,163,547,121,548,448,9,224
	FDB	334,549,561,7,562,590,449,20,62,567,450,451,452
	FDB	305,166,409,231,568,428,413,164,588,453,349,109
	FDB	$FF00	; caption#0
		; u
	FDB	85,286,287,302,355,550,122,455,454
	FDB	$FF00	; caption#0
		; v
	FDB	86,551,308,336,456,295,225,293
	FDB	$FF00	; caption#0
		; w
	FDB	87,21,405,458,459,12,552,162,589,460,461,219,217
	FDB	319,462,325,463,553
	FDB	$FF00	; caption#0
		; x
	FDB	88,218
	FDB	$FF00	; caption#0
		; y
	FDB	89,288,313,464,554,465
	FDB	$FF00	; caption#0
		; z
	FDB	90,466,555,296
; suffix words
	FDB	$FF00	; caption#0
	FDB	$FF06	; caption#6
	FDB	486,487,200,535,557,558,559
;female words
	FDB	$FF00	; caption#0
	FDB	$FF02	; caption#2
	FDB	128,129,130,131,132,133,134,135,136,137
	FDB	144,145,146,147,148,149,150,151,152,153
	FDB	154,155,156,157,160,141,161,158,140,159,143,142,138,139
;numerics
	FDB	$FF00	; caption#0
	FDB	$FF03	; caption#3
	FDB	"0","1","2","3","4","5","6","7","8","9",116,41,43,190
	FDB	191,192,193,194,195,196
	FDB	40,64,123,198,124,127,188,189,24,19,245
;phrase words
	FDB	$FF00	; caption#0
	FDB	$FF04	; caption#4
	FDB	183,180,177,187,11,186,185,184,197,182,181,175,178,179
	FDB	176,186,254
;CW chrs
	FDB	$FF00	; caption#0
	FDB	$FF05	; caption#5
	FDB	44,32,45,46,47,61,63,246
ALPHAlst_e DS	0
	FDB	$FFFF					; end of list

wordbase

;   ****************************************
; ***** SPEECH DATA **************************
;   ****************************************

	ORG	$0000

HICAR	FDB	HICHR		; moved HICHR here to kill 2birds...
	FDB	ALPHAlst_e	; save alpha list end addr

	#INCLUDE "FFWRDAr.asm"
	#INCLUDE "VM71003r.asm"
	#INCLUDE "FFWRDBr.asm"
	#INCLUDE "FFWRDCr.asm"
	#INCLUDE "FFWRDDr.asm"
	#INCLUDE "FFWRDEr.asm"
	#INCLUDE "FFWRDFr.asm"
	#INCLUDE "NEWr.ASM"
	#INCLUDE "NEW3r.ASM"
	#INCLUDE "NEW4r.ASM"
	#INCLUDE "NEW5r.ASM"
	#INCLUDE "FFWRDGr.asm"
	#INCLUDE "NEW6r.ASM"
	#INCLUDE "NEW7r.ASM"
	#INCLUDE "NEW8r.ASM"
	#INCLUDE "OVERIDEr.asm"

