if exist "i.inc" ( erase i.inc )
call "C:\Documents and Settings\Joe Haas\My Documents\1ffsys\ASM11\asm11.exe" word3_tiva.asm -s+ -o- -E+
