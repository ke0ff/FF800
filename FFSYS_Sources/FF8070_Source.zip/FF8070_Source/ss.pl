#!/usr/bin/env perl                                                                                             
#This script includes the S00/S01 command lines and stitches the main and banked assembly object files
# into a single object ready for loading into the FF-800 system.

######## these lines appear to do nothing.  Sorry, I have no idea why they are here, and I don't have time
#	to try and get rid of them.

my $fileName=$ARGV[0];
my $searchStr=$ARGV[1];
my $replaceStr=$ARGV[2];

print ("\nFilename:",$fileName,"\n");
print ("Search String:",$searchStr,"\n");
print ("Replace String:",$replaceStr,"\n\n");
######## end of seemingly dumb code.

open(FILE,"A_bank0.s19") || die("Cannot Open File A_bank0.s19");
my(@fcont) = <FILE>;
close FILE;

open(FOUT,">aa.s19") || die("Cannot Open File aa.s19");
#print FOUT "S00\n";
foreach $line (@fcont) {
    if($line =~ "S9030000FC\n"){}
    else{
	print FOUT $line;
	}
}
#print FOUT "S01\n";

open(FILE,"sbank0.s19") || die("Cannot Open File sbank0.s19");
my(@fcont) = <FILE>;
close FILE;
foreach $line (@fcont) {
    if($line =~ "S9030000FC\n"){}
    else{
	print FOUT $line;
	}
}
open(FILE,"sbank1.s19") || die("Cannot Open File sbank1.s19");
my(@fcont) = <FILE>;
close FILE;
foreach $line (@fcont) {
    if($line =~ "S9030000FC\n"){}
    else{
	print FOUT $line;
	}
}
open(FILE,"sbank2.s19") || die("Cannot Open File sbank2.s19");
my(@fcont) = <FILE>;
close FILE;
foreach $line (@fcont) {
    if($line =~ "S9030000FC\n"){}
    else{
	print FOUT $line;
	}
}
open(FILE,"sbank3.s19") || die("Cannot Open File sbank3.s19");
my(@fcont) = <FILE>;
close FILE;
foreach $line (@fcont) {
    if($line =~ "S9030000FC\n"){}
    else{
	print FOUT $line;
	}
}
#word3.s19 already has S01 & S02 command lines embedded.  S9 record is also there already
open(FILE,"word3.s19") || die("Cannot Open File word3.s19");
my(@fcont) = <FILE>;
close FILE;
foreach $line (@fcont) {
	print FOUT $line;
}

close FOUT;
