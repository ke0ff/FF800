FF-8090 BUILD AND PGM Notes
ke0ff
03/10/2021

Update SERNUM.ASM with desired S/N
Build using "as3_FF8090_assembly.bat".  This builds the main and SN
EEPROM objects.

Connect serial port to PGMR hardware and start a terminal session at 115.2 Kbaud.
Set the "DEV" to "E9"
Blank check mem ("B" and "B eprom").
Fill PGMR memory "f ff"
Enter "U"pload then send the 8090MAIN.S19 file
"PGM EPROM" and wait for progress bar to fill (takes a minute or two).
"V EPROM" and verify OK response.

Fill PGMR memory "f ff"
Enter "U"pload then send the approproiate SERNUM.S19 file
"PGM" and wait for progress bar to fill (takes a 10 or 20 sec).
"V" and verify OK response.

Set CONFIG register:
For the E9, the register is organized as follows:
[0   0   0   0   NOSEC   NOCOP   ROMON   EEON]
NOSEC = 1
NOCOP = 1
ROMON = 1
EEON = 1

Enter "C 0f" at the terminal.

Enter "DEV OFF" and remove the MCU from the PGMR hardware.
